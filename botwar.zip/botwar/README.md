# SELFBOT WAR
[![PrankBots](https://img.fireden.net/v/image/1461/72/1461725093324.gif "Prankbots")](https://bit.ly/2xbVxlh)

## VPS SERVER
- install module
```
apt-get install python3
apt-get install python3-tz
pip3 install rsa requests bs4 gtts humanfriendly googletrans thrift==0.11.0
```
## TERMINAL CLOUDS
```
sudo apt-get install python3
sudo apt-get install pyhton3-tz
sudo pip3 install rsa requests bs4 gtts humanfriendly googletrans thrift==0.11.0
```
- runner
```
cd botwar
python3 botwar.py
```
*LINE Messaging's private API*
*Modifed by: PrankBot*

- LINE UPDATE
september 2018
# [TUTORIAL](https://www.youtube.com/channel/UCycBrqSWEHdk-slnhUmGWiQ)
V3.1 last update::
- oktober/2018
# official bots
<a href="https://line.me/R/ti/p/%40gnh2780p"><img height="36" border="0" alt="PrankBots" src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png"></a>
# Creator bots
<a href="https://line.me/R/ti/p/~adiputra.95"><img height="36" border="0" alt="Add Friend" src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png"></a>
