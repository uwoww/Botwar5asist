from linepy import *
from akad.ttypes import *
from multiprocessing import Pool, Process
from datetime import datetime
import time,random,sys,json,codecs,threading,glob,re,os,subprocess,asyncio
from datetime import datetime, timedelta
from time import sleep
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, pytz, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, urllib, urllib.parse
_session = requests.session()
botStart = time.time()
settings = {
    "line": "EyFnTU8xqyyM2nTLbMe2.0YHYmMsAt7PYqXoh0yEpiG.dGbSHy1ThaUhEMk/w9dJVmxzqEuDfrLGGzd9yN7TMhA=",
    "pb1": "EykOId9TilW5KvaeWW71.3GmGwqOJO8BjxEGoJaz1Cq.66u69mu8A4clRkXo5l0UI59SeYe5mn3W6kqc5VA8GwQ=",
    "pb2": "Eydr5I8XVeuy8NWtnHYa.ToHGDOQ1tf99COLbYnGD6G.3C5wf/4Oe77y5rsQzzgTWiJNLoQ0FuGN4u8RaAhDvBY=",
    "kunci": False,
    "kata": "prank",
    "blacklist": {}
}
line = LINE(settings["line"])
line.log("Auth Token : " + str(line.authToken))
channelToken = line.getChannelResult()
pb1 = LINE(settings["pb1"])
pb1.log("Auth Token : " + str(pb1.authToken))
pb2 = LINE(settings["pb2"])
pb2.log("Auth Token : " + str(pb2.authToken))
oepoll = OEPoll(line)
lineProfile = line.getProfile()
lineSettings = line.getSettings()
myBOG = line.profile.mid
pb1BOG = pb1.getProfile().mid
pb2BOG = pb2.getProfile().mid
mid = line.getProfile().mid
Bots = [myBOG,pb1BOG,pb2BOG]
settings = {
    "kunci": False,
    "kata": "prank",
    "blacklist": {}
}
Drop_Xv = "u58b4ebbe0cc52d5389669c0957de9e57" #ID_DROPING_BOTS
Xv_WIN = "u58b4ebbe0cc52d5389669c0957de9e57" #ID_WINDOWS_XP
Xv_LAN = "u58b4ebbe0cc52d5389669c0957de9e57" #ID_SERVER_LAN
Xv_Servic = "u58b4ebbe0cc52d5389669c0957de9e57" #ID_PROV_SERVICE
Xv_DxD = "u58b4ebbe0cc52d5389669c0957de9e57" #ID_SYSTEM_BOTS
Line_Import = [Drop_Xv,Xv_WIN,Xv_LAN,Xv_Servic,Xv_DxD] #ALL_IMPORTING
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    time.sleep(5)
    python = sys.executable
    os.execl(python, python, *sys.argv)
def logError(text):
    line.log("[ ERROR ] " + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("PrankBots.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
def command(text):
    pesan = text.lower()
    if settings["kunci"] == True:
        if pesan.startswith(settings["kata"]):
            prankbot = pesan.replace(settings["kata"],"")
        else:
            prankbot = "Undefined command"
    else:
        prankbot = text.lower()
    return prankbot
def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            setKey = settings["kata"].title()
            if settings["kunci"] == False:
                 setKey = ''
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != line.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        prankbot = command(text)
                        if prankbot == "help":
                            line.sendMessage(to,"╭══════════════════╮\n│╭━━━━━╦════╦━━━━━╮\n┣[]►▶The-People Team      ◀\n┣[]►▶            Menu                ◀\n│╰━━━━━╩━━━━╩━━━━━╯\n│╭━━━━━╦════╦━━━━━╮\n│┣[]► Me\n│┣[]► Bye\n│┣[]► Gas 「@」\n│┣[]► Cancel\n│┣[]► Respon\n│┣[]► Speed\n│┣[]► Banlist\n│┣[]► Backup\n│┣[]► Myteam\n│┣[]► Clearban\n│┣[]► People\n│┣[]► People in\n│┣[]► People out\n│┣[]► Daftar bot\n│╰━━━━━╩━━━━╩━━━━━╯\n│╭━━━━━╦════╦━━━━━╮\n┣[]►▶      Terimakasih          ◀\n│╰━━━━━╩━━━━╩━━━━━╯\n╰══════════════════╯")
                        if prankbot == "backup":
                            try:
                                line.findAndAddContactsByMid(pb1BOG)
                                line.findAndAddContactsByMid(pb2BOG)
                                line.findAndAddContactsByMid(Drop_Xv)
                                line.findAndAddContactsByMid(Xv_WIN)
                                line.findAndAddContactsByMid(Xv_LAN)
                                line.findAndAddContactsByMid(Xv_Servic)
                                line.findAndAddContactsByMid(Xv_DxD)
                                pb1.findAndAddContactsByMid(myBOG)
                                pb1.findAndAddContactsByMid(pb2BOG)
                                pb1.findAndAddContactsByMid(Drop_Xv)
                                pb1.findAndAddContactsByMid(Xv_WIN)
                                pb1.findAndAddContactsByMid(Xv_LAN)
                                pb1.findAndAddContactsByMid(Xv_Servic)
                                pb1.findAndAddContactsByMid(Xv_DxD)
                                pb2.findAndAddContactsByMid(myBOG)
                                pb2.findAndAddContactsByMid(pb1BOG)
                                pb2.findAndAddContactsByMid(Drop_Xv)
                                pb2.findAndAddContactsByMid(Xv_WIN)
                                pb2.findAndAddContactsByMid(Xv_LAN)
                                pb2.findAndAddContactsByMid(Xv_Servic)
                                pb2.findAndAddContactsByMid(Xv_DxD)
                                line.sendMessage(to,"╭═════════════╮\n│╭━━━╦═══╦━━━╮\n┣[]► On Ready\n│╰━━━╩━━━╩━━━╯\n╰═════════════╯")
                            except:
                                line.sendMessage(to,"╭═════════════╮\n│╭━━━╦═══╦━━━╮\n┣[]► Ready\n│╰━━━╩━━━╩━━━╯\n╰═════════════╯")

                        if prankbot == "people in":
                            anggota = [pb1BOG,pb2BOG]
                            line.inviteIntoGroup(msg.to, anggota)
                            pb1.acceptGroupInvitation(msg.to)
                            pb2.acceptGroupInvitation(msg.to)

                        elif prankbot == "people":
                            G = line.getGroup(msg.to)
                            ginfo = line.getGroup(msg.to)
                            G.preventedJoinByTicket = False
                            line.updateGroup(G)
                            invsend = 0
                            Ticket = line.reissueGroupTicket(msg.to)
                            pb1.acceptGroupInvitationByTicket(msg.to,Ticket)
                            pb2.acceptGroupInvitationByTicket(msg.to,Ticket)
                            G = pb2.getGroup(msg.to)
                            pb1.sendMessage(msg.to, "Hallow Fams")
                            pb2.sendMessage(msg.to, "Hallow Fams")
                            G.preventedJoinByTicket = True
                            line.updateGroup(G)

                        elif prankbot.startswith("gas "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        pb1.kickoutFromGroup(to,[ls])
                                        print (to,[ls])
                                    except:
                                        pb2.kickoutFromGroup(to,[ls])
                                        print (to,[ls])

                        elif prankbot == "speed":
                            start = time.time()
                            line.sendMessage(msg.to, "Loading..")
                            elapsed_time = time.time() - start
                            line.sendMessage(msg.to, "Speed : %sms" % (elapsed_time))

                        elif prankbot == "me":
                            contact = line.getContact(sender)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            line.sendMessage(msg.to, "Nama : "+str(contact.displayName))
                            line.sendMessage(msg.to, None,contentMetadata={'mid': sender}, contentType=13)
                            line.sendMessage(msg.to, contact.displayName, contentMetadata={'countryCode': 'ID', 'i-installUrl': 'line.me/ti/p/~seberlin2309', 'a-packageName': 'com.spotify.music', 'linkUri': 'line.me/ti/p/~seberlin2309', 'subText': contact.statusMessage, 'a-installUrl': 'line.me/ti/p/~seberlin2309', 'type': 'mt', 'previewUrl': image, 'a-linkUri': 'line.me/ti/p/~seberlin2309', 'Text': contact.displayName,'id': 'mt000000000a6b79f9', 'i-linkUri': 'line://ti/p/~seberlin2309'}, contentType=19)

                        elif prankbot == "daftar bot":
                            ma = ""
                            a = 0
                            for m_id in Bots:
                                a = a + 1
                                end = '\n'
                                ma += str(a) + "┣[]►▶" +line.getContact(m_id).displayName + "\n│"
                            line.sendMessage(msg.to,"╭══════════════╮\n│╭━━━╦═══╦━━━╮\n┣[]►▶      BOT        ◀\n│╰━━━╩━━━╩━━━╯\n│"+ma+"╭━━━╦═══╦━━━╮\n┣[]►▶Total: %s BOT ◀\n   ╰━━━╩━━━╩━━━╯" %(str(len(Bots))))

                        elif prankbot == "banlist":
                                if settings["blacklist"] == {}:
                                    line.sendMessage(to,"╭═════════════╮\n│╭━━━╦═══╦━━━╮\n┣[]► No Blacklist\n│╰━━━╩━━━╩━━━╯\n╰═════════════╯")
                                else:
                                    line.sendMessage(to,"╭═══════List blacklist═══════╮")
                                    h = ""
                                    for i in settings["blacklist"]:
                                        h = line.getContact(i)
                                        line.sendContact(to,i)

                        elif prankbot == "clearban":
                            settings["blacklist"] = {}
                            line.sendMessage(to,"╭═════════════╮\n│╭━━━╦═══╦━━━╮\n┣[]► Success\n│╰━━━╩━━━╩━━━╯\n╰═════════════╯")

                        elif prankbot == "myteam":
                            for i in Bots:
                                contact = line.getContact(i)
                                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                line.sendMessage(msg.to, contact.displayName, contentMetadata={'countryCode': 'ID', 'i-installUrl': 'line.me/ti/p/~seberlin2309', 'a-packageName': 'com.spotify.music', 'linkUri': 'line.me/ti/p/~seberlin2309', 'subText': contact.statusMessage, 'a-installUrl': 'line.me/ti/p/~seberlin2309', 'type': 'mt', 'previewUrl': image, 'a-linkUri': 'line.me/ti/p/~seberlin2309', 'Text': contact.displayName,'id': 'mt000000000a6b79f9', 'i-linkUri': 'line://ti/p/~seberlin2309'}, contentType=19)

                        elif prankbot == "respon":
                            profile = pb1.getProfile()
                            text = "􀜁􀅔􏿿Banyak Bacot"
                            pb1.sendMessage(to, text)
                            profile = pb2.getProfile()
                            text = "􀜁􀅔􏿿Senggol Gas ampe mati"
                            pb2.sendMessage(to, text)

                        elif prankbot == "bye":
                            pb1.leaveGroup(msg.to)
                            pb2.leaveGroup(msg.to)
                            line.sendMessage(to,"╭══ᴄʀᴇᴀᴛᴏʀ τ̯͍̕ɧ̹ͦ͡ε͔̾͘ ℘ε͍̦ͮσ̲̓̀℘ɭ̤͘͡ε̝ͥ̕ τ̭͉͗ε̧̹̄ศͨ͗ͅɱ̙̇͢══╮")
                            line.sendContact(to, 'u58b4ebbe0cc52d5389669c0957de9e57')
                            line.leaveGroup(msg.to)

                        elif prankbot == "people out":
                            pb1.leaveGroup(msg.to)
                            pb2.leaveGroup(msg.to)

                        elif prankbot == "cancel" and sender == mid:
                            if msg.toType == 2:
                                group = line.getGroup(to)
                                if group.invitee is None or group.invitee == []:
                                    line.sendMessage(to, "Tidak ada pendingan")
                                else:
                                    invitee = [contact.mid for contact in group.invitee]
                                    for inv in invitee:
                                        line.cancelGroupInvitation(to, [inv])
                                        time.sleep(1)
                                    line.sendMessage(to, "Berhasil membersihkan {} pendingan".format(str(len(invitee))))

        if op.type == 19 or op.type == 32:
            if myBOG in op.param3:
                if op.param2 in Bots:
                    pb1.inviteIntoGroup(op.param1,[op.param3])
                    line.acceptGroupInvitation(op.param1)
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        pb1.inviteIntoGroup(op.param1,[op.param3])
                        pb2.kickoutFromGroup(op.param1,[op.param2])
                        line.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            pb1.kickoutFromGroup(op.param1,[op.param2])
                            pb2.inviteIntoGroup(op.param1,[op.param3])
                            line.acceptGroupInvitation(op.param1)
                        except:
                            pass
            if pb1BOG in op.param3: #BAGIAN BACKUP LEWAT QR
                if op.param2 in Bots:
                    pb1.inviteIntoGroup(op.param1,[op.param3])
                    line.acceptGroupInvitation(op.param1)
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        G = line.getGroup(op.param1)
                        G.preventedJoinByTicket = False
                        line.updateGroup(G)
                        Ticket = line.reissueGroupTicket(op.param1)
                        pb1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        pb2.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        G = pb2.getGroup(op.param1)
                        G.preventedJoinByTicket = False
                        pb2.updateGroup(G)
                        Ticket = pb2.reissueGroupTicket(op.param1)
                        pb1.acceptGroupInvitationByTicket(op.param1,Ticket)
                        pb1.kickoutFromGroup(op.param1,[op.param2])
            if pb2BOG in op.param3:
                if op.param2 in Bots:
                    pb1.inviteIntoGroup(op.param1,[op.param3])
                    line.acceptGroupInvitation(op.param1)
                else:
                    settings["blacklist"][op.param2] = True
                    try:
                        line.inviteIntoGroup(op.param1,[op.param3])
                        pb1.kickoutFromGroup(op.param1,[op.param2])
                        pb2.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])
                            pb1.inviteIntoGroup(op.param1,[op.param3])
                            pb2.acceptGroupInvitation(op.param1)
                        except:
                            pass
        if op.type == 17:
            if op.param2 in settings["blacklist"]:
                try:
                    pb1.kickoutFromGroup(op.param1,[op.param2])
                except:
                    try:
                        pb2.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        line.kickoutFromGroup(op.param1,[op.param2])
    except Exception as error:
        logError(error)
        if op.type == 59:
            print (op)
while True:
    try:
      ops=oepoll.singleTrace(count=50)
      if ops != None:
        for op in ops: 
          bot(op)
          oepoll.setRevision(op.revision)
    except Exception as e:
        line.log("[SINGLE_TRACE] ERROR : " + str(e))